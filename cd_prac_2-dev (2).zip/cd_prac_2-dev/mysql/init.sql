-- Database initialization for project02
CREATE DATABASE IF NOT EXISTS project02;
USE project02;

-- Create the items table if it doesn't exist
CREATE TABLE IF NOT EXISTS items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(50) NOT NULL,
    description VARCHAR(255)
);

-- Insert 10 items if the table is empty
INSERT INTO items (name, description)
SELECT * FROM (SELECT 'Item 1', 'Description for item 1') AS tmp
WHERE NOT EXISTS (SELECT * FROM items LIMIT 1);

INSERT INTO items (name, description) VALUES
('Item 2', 'Description for item 2'),
('Item 3', 'Description for item 3'),
('Item 4', 'Description for item 4'),
('Item 5', 'Description for item 5'),
('Item 6', 'Description for item 6'),
('Item 7', 'Description for item 7'),
('Item 8', 'Description for item 8'),
('Item 9', 'Description for item 9'),
('Item 10', 'Description for item 10');


-- Database initialization for city_council_db
CREATE DATABASE IF NOT EXISTS city_council_db;
USE city_council_db;

-- Create the homes table if it doesn't exist
CREATE TABLE IF NOT EXISTS homes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    owner_name VARCHAR(100) NOT NULL,
    address VARCHAR(255) NOT NULL,
    UNIQUE(owner_name, address) -- Ensures each owner/address pair is unique
);

-- Insert initial data for testing
INSERT INTO homes (owner_name, address) VALUES
('Jane Smith', '456 Elm St'),
('Alice Johnson', '789 Oak St'),
('Bob Brown', '101 Maple Ave');


-- Create a user for the city council database
CREATE USER IF NOT EXISTS 'council_user'@'%' IDENTIFIED BY 'councilpass';

-- Grant necessary privileges to the user on the city_council_db database
GRANT ALL PRIVILEGES ON city_council_db.* TO 'council_user'@'%';

-- Apply the changes
FLUSH PRIVILEGES;