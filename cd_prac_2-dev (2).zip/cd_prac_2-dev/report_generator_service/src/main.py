from fastapi import FastAPI, HTTPException, Header
from pydantic import BaseModel, Field
from fpdf import FPDF
import os
import base64
from datetime import datetime
import random
import asyncio

app = FastAPI()

# Request data model with boolean result field
class Sensor(BaseModel):
    name: str
    type: str

class ReportRequest(BaseModel):
    owner_name: str = Field(..., example="John Doe")
    owner_address: str = Field(..., example="123 Main St, Springfield")
    house_name: str = Field(..., example="Green House")
    house_address: str = Field(..., example="456 Elm St, Springfield")
    sensors: list[Sensor] = Field(..., example=[{"name": "Temperature Sensor", "type": "Thermometer"}])
    result: bool = Field(..., description="Result of the certification: true for Compliant, false for Non-Compliant")

# PDF generation function
def generate_pdf(data: ReportRequest):
    pdf = FPDF()
    pdf.add_page()
    pdf.set_font("Arial", "B", 12)

    # Generate the certification timestamp
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    pdf.cell(200, 10, "Energy Certification Report", ln=True, align="C")
    pdf.ln(10)

    # Determine the compliance result text
    result_text = "Compliant" if data.result else "Non-Compliant"

    # Add the certification timestamp and compliance result
    pdf.cell(200, 10, f"Certification Date: {timestamp}", ln=True)
    pdf.cell(200, 10, f"Result: {result_text}", ln=True)  # Display "Compliant" or "Non-Compliant"
    pdf.ln(10)

    # Add Owner and House information
    pdf.cell(200, 10, f"Owner: {data.owner_name}", ln=True)
    pdf.cell(200, 10, f"Owner Address: {data.owner_address}", ln=True)
    pdf.cell(200, 10, f"House Name: {data.house_name}", ln=True)
    pdf.cell(200, 10, f"House Address: {data.house_address}", ln=True)
    pdf.ln(10)

    # Add sensors
    pdf.cell(200, 10, "Sensors:", ln=True)
    for sensor in data.sensors:
        pdf.cell(200, 10, f"  - {sensor.name} ({sensor.type})", ln=True)

    # Format owner_name
    owner_name_snake = data.owner_name.lower().replace(" ", "_")  # Convert to lowercase and snake case

    # Save PDF to file with owner_name
    file_path = f"storefiles/reports/{owner_name_snake}_report.pdf"
    pdf.output(file_path)
    return file_path

# Endpoint to generate report
@app.post("/generate-report")
async def create_report(data: ReportRequest, x_api_key: str = Header(...)):
    # Validate API Key
    if x_api_key != os.getenv("API_KEY"):
        raise HTTPException(status_code=401, detail="Invalid API Key")

    # Simulate a 30% chance of a 500 error
    if random.random() < 0.3:
        raise HTTPException(status_code=500, detail="Internal Server Error: Simulated failure.")

    # Introduce a random delay of 10 or 20 seconds
    delay = random.choice([10, 20])
    await asyncio.sleep(delay) 

    # Generate PDF report
    try:
        file_path = generate_pdf(data)
        with open(file_path, "rb") as f:
            pdf_content = base64.b64encode(f.read()).decode('utf-8')
        return {"status": "success", "report_file": pdf_content}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))