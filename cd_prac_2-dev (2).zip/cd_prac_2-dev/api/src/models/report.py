from sqlalchemy import Column, Integer, ForeignKey, LargeBinary
from sqlalchemy.orm import relationship
from database import Base

class Report(Base):
    __tablename__ = "Reports"
    id = Column(Integer, primary_key=True, index=True)
    house_id = Column(Integer, ForeignKey('houses.id'), nullable=False)
    pdf_base64 = Column(LargeBinary, nullable=False)  # Para almacenar PDF en formato base64

    owner = relationship('House', backref='Reports')
