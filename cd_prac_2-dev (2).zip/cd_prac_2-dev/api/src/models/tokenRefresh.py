from sqlalchemy import Column, String
from database import Base

class TokenRefresh(Base):
    __tablename__ = "tokens"

    username = Column(String(50), primary_key=True, index=True)  # Máximo 50 caracteres
    token = Column(String(255), nullable=False)  # Máximo 255 caracteres
