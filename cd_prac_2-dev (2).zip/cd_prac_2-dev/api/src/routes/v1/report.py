from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from dao import houses_sql_dao, report_sql_dao, user_sql_dao
from models.report import Report
from utils.jwt_utils import verify_token, role_required, get_current_user_role, oauth2_scheme
from database import get_db
import requests_async as requests
import json
import base64
import random
import string
from logger import logger  # Importar el logger

API_URL = "http://report_generator_service:8091/generate-report"
API_KEY = "7f8d92c7a5e"

router = APIRouter()

@router.post("/report", status_code=status.HTTP_200_OK, dependencies=[Depends(verify_token), Depends(role_required(["admin", "technician", "owner"]))])
async def download_report(house_id: int, db: Session = Depends(get_db), token: str = Depends(oauth2_scheme)):
    
    house = houses_sql_dao.get_house_by_id(db, house_id)
    
    if house == None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="House not found"
        )
    

    report = report_sql_dao.get_report_by_house_id(db, house_id)

    await send_webhook_request(home_id=house.id,owner_name=house.owner.username, owner_address=house.address, report_status=1, token=None)

    if report == None:
        
        sensors = []

        if house.sensors:
            if isinstance(house.sensors, list):
                for sensor in house.sensors:
                    # Comprobar si ambos campos 'name' y 'type' están presentes
                    if sensor.get('name') and sensor.get('type'):
                        sensor_dict = {"name": sensor['name'], "type": sensor['type']}
                        sensors.append(sensor_dict)
            else:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Invalid format for sensors, expected a list"
                )
        
        response = await generate_report_service(house_id=house_id, owner_name=house.owner.username,owner_address=house.address, house_name=house.name, house_address=house.address, sensors=sensors, result="true", token=token)
        
        pdfbase64 = response.get("report_file")
    
        report = Report(
            house_id = house.id,
            pdf_base64 = pdfbase64.encode('utf-8')
        )

        report_sql_dao.save_report(db=db, report=report)

    await send_webhook_request(home_id=house_id,owner_name=house.owner.username, owner_address=house.address, report_status=2, token=token)

    return {"pdf_report": f"{report.pdf_base64}"}

@router.get("/report", status_code=status.HTTP_200_OK, dependencies=[Depends(verify_token), Depends(role_required(["admin", "technician", "owner"]))])
async def download_report(house_id: int, db: Session = Depends(get_db)):
    
    house = houses_sql_dao.get_house_by_id(db, house_id)
    if house == None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,  # Código de estado 404 para "No encontrado"
            detail="House not found"
        )
    
    # Generar un código aleatorio de 6 caracteres
    random_code = ''.join(random.choices(string.ascii_lowercase + string.digits, k=6))
    
    # Crear la ruta del archivo con el código aleatorio
    output_pdf_path = f"storefiles/reports/{random_code}_{house.owner.username}_report.pdf"

    report = report_sql_dao.get_report_by_house_id(db, house_id)
    if report is None:
        logger.warning("Reporte no generado aún para la casa ID: %d", house_id)
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="The report has not been generated yet."
        )

    generate_pdf_from_base64(base64_data=report.pdf_base64, output_pdf_path=output_pdf_path)
    logger.info("Reporte descargado y archivo PDF generado exitosamente: %s", output_pdf_path)

    return {"pdf_report": f"{report.pdf_base64}"}




async def generate_report_service(house_id:int, owner_name, owner_address, house_name, house_address, sensors, result, token):

    
    payload = json.dumps({
        "owner_name": owner_name,
        "owner_address": owner_address,
        "house_name": house_name,
        "house_address": house_address,
        "sensors": sensors,
        "result": result
    })
    headers = {
        'x-api-key': API_KEY,
        'Content-Type': 'application/json'
    }

    response = await requests.post(API_URL, headers=headers, data=payload)

    # Check if the response status code indicates an error
    if response.status_code != 200:
        await send_webhook_request(home_id=house_id,owner_name=owner_name, owner_address=house_address, report_status=3, token=None)
        raise HTTPException(
            status_code=response.status_code,
            detail=f"Error generating report: {response.text}"
        )

    logger.info("Reporte generado exitosamente a través del servicio externo.")
    try:
        return response.json()
       
    except json.JSONDecodeError:
        await send_webhook_request(home_id=house_id,owner_name=owner_name, owner_address=owner_address, report_status=3, token=None)
        raise HTTPException(
            status_code=500,
            detail="Invalid response from server: unable to parse JSON"
        )
    

def generate_pdf_from_base64(base64_data: str, output_pdf_path: str):
        logger.info("Generando archivo PDF desde base64: %s", output_pdf_path)
        # Decodificar la cadena base64
        pdf_data = base64.b64decode(base64_data)
        # Escribir los bytes en un archivo PDF
        with open(output_pdf_path, 'wb') as pdf_file:
            pdf_file.write(pdf_data)
        print(f"PDF generado en {output_pdf_path}")


async def send_webhook_request(home_id: int, owner_name: str, owner_address: str, report_status: int, token: str):
    url = "http://webhook_service:8089/webhook"

    # Payload con parámetros personalizados
    payload = json.dumps({
        "id": 123,  # ID estático como en tu ejemplo
        "home_id": home_id,
        "owner_name": owner_name,
        "address": "C/ Melancolia 13",  # Dirección fija como en el ejemplo
        "report_status": report_status,
        "token" : token
    })

    # Encabezados de la solicitud
    headers = {
        'Content-Type': 'application/json'
    }

    try:
        # Realizar la solicitud POST
        response = await requests.request("POST", url, headers=headers, data=payload)

        # Imprimir y devolver la respuesta del servidor
        print(f"Response Status Code: {response.status_code}")
        print(f"Response Body: {response.text}")
        return response.text
    except Exception as e:
        print(f"Error al enviar la solicitud al webhook: {e}")
        return None