from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List
from dao import houses_sql_dao
from models.house import House
from utils.jwt_utils import verify_token, role_required, get_current_user_role, get_current_username
from database import get_db
from routes.validation import HouseCreateRequest
import requests_async as requests
import xml.etree.ElementTree as ET
from logger import logger 

router = APIRouter()

@router.post("/", status_code=status.HTTP_201_CREATED, 
             dependencies=[Depends(verify_token), Depends(role_required(["admin", "technician", "owner"]))])
async def create_house_endpoint(user_id: int, request: HouseCreateRequest, role=Depends(get_current_user_role), db: Session=Depends(get_db), username: str=Depends(get_current_username)):
    logger.info("Inicio de creación de casa para usuario ID: %d, nombre: %s", user_id, request.name)
    user = houses_sql_dao.get_user_by_id(db=db, user_id=user_id)

    if "owner" in role and user.username not in username:
        logger.warning("Permiso denegado: El usuario %s intentó crear una casa para otro usuario.", username)
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Access forbidden: insufficient permissions, The current user can not create house for other users"
        )

    isHomeInCityCouncil : bool = await verifyHomeCityCouncil(owner_name=request.name, address=request.address)
    if isHomeInCityCouncil == False:
        await registerHomeCityCouncil(owner_name=user.username, address=request.address)

    new_house = House(
        name=request.name,
        address=request.address,
        description=request.description,
        number_of_rooms=request.number_of_rooms,
        sensors=request.sensors,
        owner_id=user_id
    )
    houses_sql_dao.create_house(db, new_house)
    logger.info("Casa creada exitosamente: %s", request.name)
    return {"message": "House created successfully"}


@router.get("/{house_id}", status_code=status.HTTP_200_OK, dependencies=[Depends(verify_token), Depends(role_required(["admin", "technician", "owner"]))])
async def get_house(user_id: int, house_id: int, db: Session=Depends(get_db), role=Depends(get_current_user_role), username: str=Depends(get_current_username)):
    logger.info("Solicitud para obtener detalles de la casa ID: %d por usuario ID: %d", house_id, user_id)
    user = houses_sql_dao.get_user_by_id(db=db, user_id=user_id)

    if "owner" in role and user.username not in username:
        logger.warning("Permiso denegado: El usuario %s intentó acceder a una casa que no le pertenece.", username)
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Access forbidden: insufficient permissions, The user Id introduced is not allowed"
        )

    house = houses_sql_dao.get_house_by_id(db, house_id)
    if not house:
        logger.warning("Casa no encontrada con ID: %d", house_id)
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="House not found")

    if "owner" in role and house.owner_id != user_id:
        logger.warning("El usuario ID: %d intentó acceder a una casa que no es suya.", user_id)
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Unauthorized")

    logger.info("Detalles de la casa ID %d obtenidos exitosamente", house_id)
    return house


@router.put("/{house_id}/description", status_code=status.HTTP_200_OK)
async def update_house_description(user_id: int, house_id: int, description: str, db: Session=Depends(get_db), role=Depends(get_current_user_role), username: str=Depends(get_current_username)):
    logger.info("Solicitud de actualización de descripción para casa ID: %d", house_id)
    user = houses_sql_dao.get_user_by_id(db=db, user_id=user_id)
    
    if "owner" in role and user.username not in username:
        logger.warning("Permiso denegado para el usuario %s en la actualización de descripción.", username)
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Access forbidden: insufficient permissions"
        )

    house = houses_sql_dao.get_house_by_id(db, house_id)
    if not house:
        logger.warning("Casa no encontrada con ID: %d", house_id)
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="House not found")

    house.description = description
    houses_sql_dao.update_house(db, house)
    logger.info("Descripción de la casa ID: %d actualizada exitosamente", house_id)
    return {"message": "House description updated successfully"}

# Delete a house
@router.delete("/{house_id}", status_code=status.HTTP_200_OK)
async def delete_house_endpoint(user_id: int, house_id: int, db: Session = Depends(get_db), role = Depends(get_current_user_role),  username:str = Depends(get_current_username)):
    logger.info("Solicitud para eliminar la casa ID: %d", house_id)
    user = houses_sql_dao.get_user_by_id(db=db,user_id=user_id)
    
    # Comprovar si la persona registrada i la persona del path es la mateixa en cas de que el rol sigui owner
    if "owner" in role:
        if user.username not in username:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Access forbidden: insufficient permissions, The user Id introduced is not allowed",
            )
    
    # Comprovar si la casa es seva en el cas de que sigui owner
    house = houses_sql_dao.get_house_by_id(db, house_id)

    if not house:
        logger.warning("Casa no encontrada con ID: %d", house_id)
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="House not found")

    if "owner" in role:
        if house.owner_id != user_id:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Access forbidden: insufficient permissions, The current user does not own the house.",
            )

    houses_sql_dao.delete_house(db, house)
    logger.info("Casa ID: %d eliminada exitosamente", house_id)
    return {"message": "House deleted successfully"}

# Search houses by description
@router.get("/search", status_code=status.HTTP_200_OK, dependencies=[Depends(verify_token), Depends(role_required(["admin", "technician", "owner"]))])
async def search_houses(user_id: int, description: str, address: str, db: Session = Depends(get_db), role = Depends(get_current_user_role),  username:str = Depends(get_current_username)):
    
    user = houses_sql_dao.get_user_by_id(db=db,user_id=user_id)

    if "owner" in role:
        if user.username not in username:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Access forbidden: insufficient permissions, The user Id introduced is not allowed",
            )
    houses_description = houses_sql_dao.search_houses_by_description(db=db, description=description, owner_id=user_id)
    houses_address = houses_sql_dao.search_houses_by_address(db=db, address=address, owner_id=user_id)

    if "admin" in role:
        houses_description = houses_sql_dao.search_houses_by_description(db=db, description=description, owner_id=None) 
        houses_address = houses_sql_dao.search_houses_by_address(db=db, address=address, owner_id=None)

    houses = houses_description + houses_address

    return houses

# List all houses for a user
@router.get("/", status_code=status.HTTP_200_OK)
async def list_houses(user_id: int, db: Session = Depends(get_db), role = Depends(get_current_user_role),  username:str = Depends(get_current_username)):

    user = houses_sql_dao.get_user_by_id(db=db,user_id=user_id)
    
    if "owner" in role:
        if user.username not in username:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Access forbidden: insufficient permissions, The user Id introduced is not allowed",
            )
        
    houses = houses_sql_dao.list_houses_for_owner(db, owner_id=user_id)

    if "admin" in role:
        houses = houses_sql_dao.list_houses_for_owner(db, owner_id=None)

    return houses

# Assign a house to a new owner
@router.post("/{house_id}/assign", status_code=status.HTTP_200_OK)
async def assign_house(house_id: int, new_owner_id: int, db: Session=Depends(get_db), role=Depends(get_current_user_role)):
    logger.info("Solicitud para reasignar la casa ID: %d al usuario ID: %d", house_id, new_owner_id)
    if "owner" in role or "technician" in role:
        logger.warning("Permiso denegado: solo los administradores pueden reasignar casas.")
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Access forbidden")

    house = houses_sql_dao.get_house_by_id(db, house_id)
    if not house:
        logger.warning("Casa no encontrada con ID: %d", house_id)
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="House not found")

    new_owner = houses_sql_dao.get_user_by_id(db, new_owner_id)
    if not new_owner:
        logger.warning("Nuevo propietario no encontrado con ID: %d", new_owner_id)
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="New owner not found")

    house.owner_id = new_owner.id
    houses_sql_dao.update_house(db, house)
    logger.info("Casa ID %d reasignada al nuevo propietario ID %d exitosamente", house_id, new_owner_id)
    return {"message": "House reassigned successfully"}


async def verifyHomeCityCouncil(owner_name: str, address: str) -> bool:
    """
    Verifica si una casa está registrada en el ayuntamiento usando un servicio SOAP.

    Args:
        owner_name (str): Nombre del propietario.
        address (str): Dirección de la casa.

    Returns:
        bool: True si la casa está registrada, False en caso contrario.
    """
    # Configuración del servicio SOAP
    url = "http://city_council_service:8093/"
    payload = f"""<?xml version="1.0" encoding="utf-8"?>
<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"
               xmlns:tns="city.council.soap.service">
  <soap:Body>
    <tns:verify_home>
         <tns:owner_name>{owner_name}</tns:owner_name>
         <tns:address>{address}</tns:address>
    </tns:verify_home>
  </soap:Body>
</soap:Envelope>
"""
    headers = {
        'Content-Type': 'text/xml; charset=utf-8',
        'SOAPAction': 'verify_home'
    }

    try:
        # Enviar la solicitud al servicio SOAP
        response =  await requests.post(url, headers=headers, data=payload)
        response.raise_for_status()  # Levanta una excepción si el estado HTTP no es 200

        # Analizar la respuesta para determinar si la casa está registrada
        return is_home_registered(response.text)

    except requests.exceptions.RequestException as e:
        print(f"Error al conectar con el servicio SOAP: {e}")
        return False


def is_home_registered(response_text: str) -> bool:
    """
    Analiza la respuesta XML del servicio SOAP para determinar si la casa está registrada.

    Args:
        response_text (str): El texto XML de la respuesta del servicio SOAP.

    Returns:
        bool: True si la casa está registrada, False en caso contrario.
    """
    try:
        # Parsear la respuesta XML
        root = ET.fromstring(response_text)

        # Buscar el valor de <tns:verify_homeResult>
        verify_home_result = root.find('.//tns:verify_homeResult', namespaces={'tns': 'city.council.soap.service'})

        # Comprobar si el valor de <tns:verify_homeResult> es 'false'
        if verify_home_result is not None and verify_home_result.text == 'false':
            return False
        return True

    except ET.ParseError as e:
        print(f"Error al parsear XML: {e}")
        return False


async def registerHomeCityCouncil(owner_name: str, address: str) -> bool:
    # Configuración del servicio SOAP
    url = "http://city_council_service:8093/"
    payload = f"""<?xml version="1.0" encoding="utf-8"?>
<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"
               xmlns:tns="city.council.soap.service">
  <soap:Body>
    <tns:add_home>
      <tns:owner_name>{owner_name}</tns:owner_name>
      <tns:address>{address}</tns:address>
    </tns:add_home>
  </soap:Body>
</soap:Envelope>
"""
    headers = {
        'Content-Type': 'text/xml; charset=utf-8',
        'SOAPAction': 'add_home'
    }

    try:
        # Enviar la solicitud al servicio SOAP
        response = await requests.post(url, headers=headers, data=payload)
        response.raise_for_status()  # Levanta una excepción si el estado HTTP no es 200

        # Analizar la respuesta para determinar si el registro fue exitoso
        return is_home_registered_or_added(response.text)

    except requests.exceptions.RequestException as e:
        print(f"Error al conectar con el servicio SOAP: {e}")
        return False


def is_home_registered_or_added(response_text: str) -> bool:
    try:
        # Parsear la respuesta XML
        root = ET.fromstring(response_text)

        # Buscar el valor de <tns:add_homeResult>
        add_home_result = root.find('.//tns:add_homeResult', namespaces={'tns': 'city.council.soap.service'})

        # Comprobar si el valor de <tns:add_homeResult> es 'Home added successfully'
        if add_home_result is not None and add_home_result.text == 'Home added successfully':
            return True
        return False

    except ET.ParseError as e:
        print(f"Error al parsear XML: {e}")
        return False
