from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.security import OAuth2PasswordRequestForm
from sqlalchemy.orm import Session
from models.user import User  # Importa el modelo de usuario
from database import get_db  # Importa la función para obtener la sesión de la base de datos
from jose import jwt
from utils.crypto_utils import hash_password, checkpw
from utils.logger import logger  # Importación del logger
import datetime
from datetime import timedelta
from config import settings
from dao import token_sql_dao, user_sql_dao
from pydantic import BaseModel

router = APIRouter()

@router.post("/token")
async def login(form_data: OAuth2PasswordRequestForm = Depends(), db: Session = Depends(get_db)):    
    # Example validation (replace with actual database check)
    logger.info(f"login called. username={form_data.username}")

    # Check if the username exists (replace this fake DB with your database query)
    user = db.query(User).filter(User.username == form_data.username).first()

    if not user:
        logger.warning("Intento fallido de inicio de sesión: Usuario no encontrado - %s", form_data.username)
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid credentials")

    # Verify the password
    if not checkpw(form_data.password, user.password):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid credentials")
    
    # Calculate the token's expiration time
    access_token_expiration = datetime.datetime.now(datetime.timezone.utc) + timedelta(minutes=int(settings.ACCESS_TOKEN_EXPIRE_MINUTES))
    refresh_token_expiration = datetime.datetime.now(datetime.timezone.utc) + timedelta(minutes=int(settings.REFRESH_TOKEN_EXPIRE_MINUTES))

    # Create access token
    access_token_payload = {
        "sub": form_data.username,
        "role": user.role,
        "iat": datetime.datetime.now(datetime.timezone.utc),
        "exp": access_token_expiration
    }
    access_token = jwt.encode(access_token_payload, settings.SECRET_KEY, algorithm="HS256")

    # Create refresh token
    refresh_token_payload = {
        "sub": form_data.username,
        "iat": datetime.datetime.now(datetime.timezone.utc),
        "exp": refresh_token_expiration
    }
    refresh_token = jwt.encode(refresh_token_payload, settings.SECRET_KEY, algorithm="HS256")

    existUser: bool = token_sql_dao.verify_token_exists(db=db, username=form_data.username)

    if existUser:
        token_sql_dao.update_token(db=db, token=refresh_token, username=form_data.username)
    else:
        # Store refresh token (Replace with database storage in production)
        token_sql_dao.add_token(db= db, username=form_data.username, token = refresh_token)

    return {
        "access_token": access_token,
        "refresh_token": refresh_token,
        "token_type": "bearer"
    }

class RefreshTokenRequest(BaseModel):
    refresh_token: str

@router.post("/refresh")
async def refresh(refresh_request: RefreshTokenRequest,  db: Session = Depends(get_db)):
    try:
        # Decode the refresh token
        payload = jwt.decode(refresh_request.refresh_token, settings.SECRET_KEY, algorithms=["HS256"])
        username = payload.get("sub")

        refresh_token_store = token_sql_dao.get_token_list(db=db)

        if not username or username not in refresh_token_store:
            raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid refresh token")

        # Check if the refresh token matches the stored one
        if refresh_token_store[username] != refresh_request.refresh_token:
            raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid refresh token")

        # Create a new access token
        access_token_expiration = datetime.datetime.now(datetime.timezone.utc) + timedelta(minutes=int(settings.ACCESS_TOKEN_EXPIRE_MINUTES))
        user = user_sql_dao.get_user_by_username(db= db, username=username)
        new_access_token_payload = {
            "sub": username,
            "role": user.role,
            "iat": datetime.datetime.now(datetime.timezone.utc),
            "exp": access_token_expiration
        }
        new_access_token = jwt.encode(new_access_token_payload, settings.SECRET_KEY, algorithm="HS256")

        # Create a new refresh token
        refresh_token_expiration = datetime.datetime.now(datetime.timezone.utc) + timedelta(minutes=int(settings.REFRESH_TOKEN_EXPIRE_MINUTES))
        new_refresh_token_payload = {
            "sub": username,
            "iat": datetime.datetime.now(datetime.timezone.utc),
            "exp": refresh_token_expiration
        }
        new_refresh_token = jwt.encode(new_refresh_token_payload, settings.SECRET_KEY, algorithm="HS256")

        token_sql_dao.update_token(db=db, token=new_refresh_token, username=username)

        return {
            "access_token": new_access_token,
            "refresh_token": new_refresh_token,
            "token_type": "bearer"
        }

    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Refresh token expired")
    except jwt.JWTError:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid token")