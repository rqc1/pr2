from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from database import get_db
from routes.validation import UserCreate
from dao import user_sql_dao
from models.user import User
from utils.jwt_utils import verify_token, get_current_user_role
from logger import logger  # Importar el logger

router = APIRouter()

# Obtener todos los usuarios
@router.get("/", status_code=status.HTTP_200_OK, dependencies=[Depends(verify_token)])
async def list_users(skip: int = 0, limit: int = 100, db: Session = Depends(get_db), role=Depends(get_current_user_role)):
    logger.info("Solicitud para obtener todos los usuarios. Skip: %d, Limit: %d", skip, limit)
    try:
        if "admin" not in role:
            logger.warning("Permiso denegado: El rol actual no tiene privilegios para listar usuarios.")
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Access forbidden: insufficient permissions",
            )

        users = user_sql_dao.get_all_users(db, skip=skip, limit=limit)
        logger.info("Lista de usuarios recuperada exitosamente. Total: %d", len(users))
        return users

    except Exception as e:
        logger.error("Error inesperado al listar usuarios: %s", str(e))
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail="Error fetching users")

# Crear un nuevo usuario
@router.post("/", status_code=status.HTTP_201_CREATED, dependencies=[Depends(verify_token)])
async def create_user(user: UserCreate, db: Session = Depends(get_db), role=Depends(get_current_user_role)):
    logger.info("Solicitud para crear un nuevo usuario: %s", user.username)
    try:
        if "admin" not in role:
            logger.warning("Permiso denegado: Rol actual sin privilegios para crear usuarios.")
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Access forbidden: insufficient permissions",
            )
        
        # Verificar si el usuario ya existe
        existing_user = user_sql_dao.get_user_by_username(db, user.username)
        if existing_user:
            logger.warning("Creación fallida: El nombre de usuario '%s' ya existe.", user.username)
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Username already exists")
        
        # Crear el nuevo usuario
        created_user = user_sql_dao.create_user(db, user)
        logger.info("Usuario creado exitosamente: %s", user.username)
        return {"id": created_user.id, "username": created_user.username, "role": created_user.role}

    except Exception as e:
        logger.error("Error inesperado al crear el usuario '%s': %s", user.username, str(e))
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail="Error creating user")

# Actualizar un usuario
@router.put("/{user_name}", status_code=status.HTTP_200_OK, dependencies=[Depends(verify_token)])
async def update_user(user_name: str, user: UserCreate, db: Session = Depends(get_db), role=Depends(get_current_user_role)):
    logger.info("Solicitud de actualización del usuario: %s", user_name)
    try:
        if "admin" not in role:
            logger.warning("Permiso denegado: Rol actual sin privilegios para actualizar usuarios.")
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Access forbidden: insufficient permissions",
            )
        
        updated_user = user_sql_dao.update_user(db, user_name, user)
        if not updated_user:
            logger.warning("Actualización fallida: El usuario '%s' no fue encontrado.", user_name)
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User not found")
        
        logger.info("Usuario '%s' actualizado exitosamente.", user_name)
        return {"id": updated_user.id, "username": updated_user.username, "role": updated_user.role}

    except Exception as e:
        logger.error("Error inesperado al actualizar el usuario '%s': %s", user_name, str(e))
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail="Error updating user")

# Eliminar un usuario
@router.delete("/{user_name}", status_code=status.HTTP_204_NO_CONTENT, dependencies=[Depends(verify_token)])
async def delete_user(user_name: str, db: Session = Depends(get_db), role=Depends(get_current_user_role)):
    logger.info("Solicitud de eliminación del usuario: %s", user_name)
    try:
        if "admin" not in role:
            logger.warning("Permiso denegado: Rol actual sin privilegios para eliminar usuarios.")
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Access forbidden: insufficient permissions",
            )

        deleted_user = user_sql_dao.delete_user(db, user_name)
        if not deleted_user:
            logger.warning("Eliminación fallida: El usuario '%s' no fue encontrado.", user_name)
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User not found")

        logger.info("Usuario '%s' eliminado exitosamente.", user_name)
        return {"message": "User deleted successfully"}

    except Exception as e:
        logger.error("Error inesperado al eliminar el usuario '%s': %s", user_name, str(e))
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail="Error deleting user")
