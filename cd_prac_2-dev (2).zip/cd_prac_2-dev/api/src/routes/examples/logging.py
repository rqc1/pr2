from fastapi import APIRouter, Depends, HTTPException, status,Request
from utils.jwt_utils import verify_token
from routes.validation import UserCreate
from utils.logger import logger, logging
import time, random, uuid
import asyncio

router = APIRouter()

@router.post("/test_loglevel", status_code=status.HTTP_200_OK)
async def test_loglevel():
    
    # Log messages at all levels
    logger.debug("This is DEBUG")
    logger.info("This is INFO")
    logger.warning("This is WARNING")
    logger.error("This is ERROR")
    logger.critical("This is CRITICAL")
    
    return  {"message": "Ok"} 

@router.post("/test_loglevel_dinamically", status_code=status.HTTP_200_OK)
async def test_loglevel_dinamically():
    # Store the original log level to restore it later
    original_log_level = logger.level

    # Define a list of log levels to demonstrate
    log_levels = [
        (logging.DEBUG, "DEBUG"),
        (logging.INFO, "INFO"),
        (logging.WARNING, "WARNING"),
        (logging.ERROR, "ERROR"),
        (logging.CRITICAL, "CRITICAL")
    ]

    # Iterate through each log level, set it, and log messages
    for level, level_name in log_levels:
        # Set the logger to the current level
        logger.setLevel(level)
        
        logger.log(level, f"\n------------------------")
        
        # Log a message indicating the level change
        logger.log(level, f"Setting log level to {level_name}")
        
        # Log messages at all levels to demonstrate filtering
        logger.debug("This is DEBUG")
        logger.info("This is INFO")
        logger.warning("This is WARNING")
        logger.error("This is ERROR")
        logger.critical("This is CRITICAL")

    # Restore the original log level
    logger.setLevel(original_log_level)
    
    return {"message": "Log level demonstration complete"}

@router.post("/test_additional_info", status_code=status.HTTP_200_OK)
async def test_additional_info():
    # Hardcoded example data for home and user
    home_data = {
        "home_id": "home_123",
        "home_name": "Green House",
        "home_address": "456 Elm St, Springfield"
    }

    user_data = {
        "user_id": "user_456",
        "user_name": "John Doe",
        "user_email": "johndoe@example.com"
    }

    # Set up additional logging context with hardcoded data from `home_data` and `user_data`
    additional_info = {
        "+user_id": user_data["user_id"],
        "+user_name": user_data["user_name"],
        "+user_email": user_data["user_email"],
        "+home_id": home_data["home_id"],
        "+home_name": home_data["home_name"],
        "+home_address": home_data["home_address"],
    }

    # Log messages at all levels with additional context
    logger.debug("DEBUG", extra=additional_info)
    logger.info("INFO", extra=additional_info)
    logger.warning("WARNING", extra=additional_info)
    logger.error("ERROR", extra=additional_info)
    logger.critical("CRITICAL", extra=additional_info)
    
    return {"message": "Ok"}

@router.post("/test_sync_log1", status_code=status.HTTP_200_OK)
async def test_sync_log1():
    
    await asyncio.sleep(2)  

    logger.info("LOG_1......[1]")
    
    delay = random.choice([12, 20])    
    # Asynchronous sleep, which won't block other requests
    await asyncio.sleep(delay)  

    logger.info("LOG_1......[2]")

    return  {"message": "Ok"} 

@router.post("/test_sync_log2", status_code=status.HTTP_200_OK)
async def test_sync_log2():

    await asyncio.sleep(2)  

    logger.info("LOG_2......[1]")
    
    delay = random.choice([8, 12])    
    await asyncio.sleep(delay)  

    logger.info("LOG_2......[2]")

    return  {"message": "Ok"}

@router.post("/test_sync_log3", status_code=status.HTTP_200_OK)
async def test_sync_log3():

    await asyncio.sleep(2)  

    logger.info("LOG_3......[1]")
    
    delay = random.choice([5, 8])    
    await asyncio.sleep(delay)

    logger.info("LOG_3......[2]")

    return  {"message": "Ok"}

@router.post("/compliant_example_1")
async def login_ok(request: Request, username: str = "pepito", password: str="#124as23Q!"):
    request_id = str(uuid.uuid4())
    
    # Log the start of the login attempt without sensitive data
    logger.info("Login attempt started", extra={"request_id": request_id, "username": username})

    try:
        # Simulate user validation
        if username != "valid_user" or password != "secure_password":
            # Log a warning for failed login attempts without exposing the password
            logger.warning("Failed login attempt", extra={"request_id": request_id, "username": username})
            raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid credentials")
        
        # Log successful login
        logger.info("Login successful", extra={"request_id": request_id, "username": username})
        
        return {"message": "Login successful", "request_id": request_id}

    except HTTPException as e:
        # Log expected HTTP exceptions without sensitive data
        logger.warning("Authentication error", extra={"request_id": request_id, "username": username})
        raise e

    except Exception as e:
        # Log unexpected errors with minimal information
        logger.error("Unexpected error during login", exc_info=True, extra={"request_id": request_id})
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail="Internal server error") from e

@router.post("/non_compliant_example_1")
async def login_nok(request: Request, username: str = "pepito", password: str="#124as23Q!"):
    # Log that exposes sensitive data (bad practice)
    logger.info(f"Login attempt: username={username}, password={password}")
    
    # Simulated authentication
    if username != "pepito" or password != "#124as23Q!":
        # Log that exposes sensitive details in a failed login attempt
        logger.error(f"Failed login for username={username} with password={password}")
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid credentials")
    
    # Success log with sensitive data
    logger.info(f"User {username} logged in successfully with password {password}")
    
    return {"message": "Login successful"}

@router.post("/compliant_example_2", status_code=status.HTTP_202_ACCEPTED)
async def process_payment_ok(request: Request, amount: float, currency: str):
    # Generate a unique request ID for traceability
    request_id = str(uuid.uuid4())
    
    # Log the start of the process with context
    logger.info("Starting payment processing", extra={
        "request_id": request_id,
        "amount": amount,
        "currency": currency,
        "client_ip": request.client.host
    })

    try:
        # Check if the amount is valid
        if amount <= 0:
            logger.warning("Invalid payment amount", extra={
                "request_id": request_id,
                "amount": amount
            })
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Amount must be greater than zero"
            )
        
        # Simulate payment processing
        logger.debug("Connecting to payment gateway...", extra={"request_id": request_id})
        # This is where the integration with an external payment service would go
        # e.g., payment_gateway.charge(amount, currency)

        # Log a successful payment
        logger.info("Payment processed successfully", extra={
            "request_id": request_id,
            "amount": amount,
            "currency": currency
        })

        # Return a success response
        return {"message": "Payment processed successfully", "request_id": request_id}

    except HTTPException as e:
        # Log specific HTTP exceptions as warnings
        logger.warning("Client error in payment processing", extra={
            "request_id": request_id,
            "status_code": e.status_code,
            "detail": e.detail
        })
        raise e  # Re-raise the exception to FastAPI's exception handler

    except Exception as e:
        # Log unexpected errors with full stack trace
        logger.error("Unexpected error during payment processing", exc_info=True, extra={
            "request_id": request_id,
            "amount": amount,
            "currency": currency
        })
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error"
        ) from e

    finally:
        # Log the end of the request handling, useful for long-running requests
        logger.info("Finished payment processing", extra={"request_id": request_id})

@router.post("/non_compliant_example_2", status_code=status.HTTP_202_ACCEPTED)
async def process_payment_nok(request: Request, amount: float, currency: str):
    
    # Start processing with no contextual information
    logger.info("Starting payment process")  # No context about what’s happening
    
    # Check if the amount is valid
    if amount <= 0:
        logger.error("Error occurred")  # Unhelpful log message, no details
        raise HTTPException(status_code=400, detail="Invalid amount")

    # Simulate payment processing with excessive logging
    logger.info("Connecting to gateway...")
    logger.info("Connected to gateway")
    logger.info("Sending payment details")
    logger.info("Awaiting response")
    logger.info("Response received")

    # Log "success" without context or confirmation of actual processing
    logger.info("Payment successful")  # Vague message, lacks transaction details

    # Return success message without logging end of function
    return {"message": "Payment complete"}
