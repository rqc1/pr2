from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from dao.item_orm_dao import ItemOrmDAO  # Importing the ORM DAO
from database import get_db
from pydantic import BaseModel

router = APIRouter()

class ItemModel(BaseModel):
    name: str
    description: str

# ------------------ ORM DAO CRUD Endpoints ------------------

# Create item (ORM)
@router.post("/items/orm", response_model=dict)
def create_item_orm(name: str, description: str, db: Session = Depends(get_db)):
    item = ItemOrmDAO.create_item(db, name, description)
    if not item:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail="Item creation failed")
    return item

# Read item by ID (ORM)
@router.get("/items/orm/{item_id}", response_model=dict)
def read_item_orm(item_id: int, db: Session = Depends(get_db)):
    item = ItemOrmDAO.get_item(db, item_id)
    if item is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Item not found")
    return item

# Update item (ORM)
@router.put("/items/orm/{item_id}", response_model=dict)
def update_item_orm(item_id: int, item: ItemModel, db: Session = Depends(get_db)):
    item = ItemOrmDAO.update_item(db, item_id, item.name, item.description)
    if item is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Item not found")
    return item

# Delete item (ORM)
@router.delete("/items/orm/{item_id}", response_model=dict)
def delete_item_orm(item_id: int, db: Session = Depends(get_db)):
    item = ItemOrmDAO.delete_item(db, item_id)
    if item is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Item not found")
    return item
