from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from dao.item_orm_dao import ItemOrmDAO  # Importing the ORM DAO
from database import get_db
from utils.jwt_utils import role_required  # Import the role_required dependency

router = APIRouter()

# ------------------ RBAC CRUD Endpoints ------------------

# Create item
@router.post("/items", response_model=dict, dependencies=[Depends(role_required(["role1", "admin"]))])
def create_item(name: str, description: str, db: Session = Depends(get_db)):
    return {"message": "OK"}

# Read item by ID
@router.get("/items/{item_id}", response_model=dict, dependencies=[Depends(role_required(["role1", "admin"]))])
def read_item(item_id: int, db: Session = Depends(get_db)):
    return {"message": "OK"}

# Update item
@router.put("/items/{item_id}", response_model=dict, dependencies=[Depends(role_required(["role1", "admin"]))])
def update_item(item_id: int, name: str, description: str, db: Session = Depends(get_db)):
   return {"message": "OK"}

# Delete item
@router.delete("/items/{item_id}", response_model=dict, dependencies=[Depends(role_required(["role1", "admin"]))])
def delete_item(item_id: int, db: Session = Depends(get_db)):
    return {"message": "OK"}