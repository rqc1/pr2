from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from dao.item_sql_dao import ItemSqlDAO  # Importing the SQL DAO
from database import get_db
from pydantic import BaseModel

router = APIRouter()

class ItemModel(BaseModel):
    name: str
    description: str

# ------------------ SQL DAO CRUD Endpoints ------------------

# Create item (SQL)
@router.post("/items/sql", response_model=dict)
def create_item_sql(name: str, description: str, db: Session = Depends(get_db)):
    item = ItemSqlDAO.create_item(db, name, description)
    if not item:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail="Item creation failed")
    return item

# Read item by ID (SQL)
@router.get("/items/sql/{item_id}", response_model=dict)
def read_item_sql(item_id: int, db: Session = Depends(get_db)):
    item = ItemSqlDAO.get_item(db, item_id)
    if item is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Item not found")
    return item

# Update item (SQL)
# @see https://fastapi.tiangolo.com/tutorial/body/#request-body-path-parameters
@router.put("/items/sql/{item_id}", response_model=dict)
def update_item_sql(item_id: int, item: ItemModel, db: Session = Depends(get_db)):
    item = ItemSqlDAO.update_item(db, item_id, item.name, item.description)
    if item is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Item not found")
    return item

# Delete item (SQL)
@router.delete("/items/sql/{item_id}", response_model=dict)
def delete_item_sql(item_id: int, db: Session = Depends(get_db)):
    item = ItemSqlDAO.delete_item(db, item_id)
    if item is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Item not found")
    return item