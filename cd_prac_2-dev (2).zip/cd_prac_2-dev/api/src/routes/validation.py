from pydantic import BaseModel, Field
from typing import Optional

class LoginRequest(BaseModel):
    username: str = Field(min_length=4)
    password: str = Field(min_length=8)

    class Config:
        json_schema_extra = {
            "example": {
                "username": "admin",
                "password": "12345678"
            }
        }

class Token(BaseModel):  
  access_token: Optional[str] = None 
  refresh_token: Optional[str] = None

class UserCreate(BaseModel):
    username: str = Field(min_length=4)
    password: str = Field(min_length=8)
    role: str = Field(pattern="^(admin|technician|owner)$")

    class Config:
        json_schema_extra = {
            "example": {
                "username": "user123",
                "password": "securepassword",
                "role": "dummy"
            }
        }


class HouseCreateRequest(BaseModel):
    name: str
    address: str
    description: str
    number_of_rooms: int
    sensors: list[dict]



class RefreshTokenRequest(BaseModel):
    refresh_token: str
