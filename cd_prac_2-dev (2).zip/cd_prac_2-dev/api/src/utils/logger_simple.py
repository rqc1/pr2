import logging
import contextvars
import uuid
import os
from config import settings
from fastapi import Request
from datetime import datetime
import json

# Configure context variables for request and correlation IDs
request_id_var = contextvars.ContextVar("request_id", default="no-request-id")
correlation_id_var = contextvars.ContextVar("correlation_id", default="no-correlation-id")

class CustomFormatter(logging.Formatter):
    def format(self, record):
        # Initialize the extra fields list
        extra_fields = {}

        # Collect fields that start with "+"
        for attr, value in record.__dict__.items():
            if attr.startswith("+"):
                # Remove the "+" prefix and add to `extra_fields`
                extra_fields[attr[1:]] = value

        # Convert extra fields to JSON format and assign to `record.extra`
        record.extra = json.dumps(extra_fields, ensure_ascii=False) if extra_fields else ""
        
        return super().format(record)

# Define filters to manage context IDs and custom fields
class ContextIdFilter(logging.Filter):
    def filter(self, record):
        record.context_id = correlation_id_var.get() or "no-correlation-id"
        return True

class GenericFilter(logging.Filter):
    def filter(self, record):
        record.hostname = settings.HOSTNAME
        record.processName = settings.SYSTEM_NAME
        return True

# Configure the logger with the custom formatter and filters
logger = logging.getLogger("template_logger")
logger.setLevel(logging.INFO)

# # Create and configure a stream handler with the custom formatter
# stream_handler = logging.StreamHandler()
# stream_handler.setFormatter(CustomFormatter(
#     "%(asctime)s %(levelname)s %(hostname)s %(processName)s[%(process)d]: %(context_id)s %(filename)s:%(lineno)d::%(funcName)s %(message)s %(extra)s"
# ))

# # Add filters to the logger (applies to all handlers automatically)
# logger.addFilter(ContextIdFilter())
# logger.addFilter(GenericFilter())

# # Add the handler to the logger
# logger.addHandler(stream_handler)