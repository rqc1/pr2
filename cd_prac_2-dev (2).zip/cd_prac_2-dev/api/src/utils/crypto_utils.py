#!/usr/bin/env python
# -*- coding: utf-8 -*-

import secrets
import bcrypt
from utils.logger import logger

def generate_hex(size_nbytes: int = 16) -> str:
    """Generate random string with specific size.

    Returns:
        str: Generated string.
    """
    # the string has nbytes random bytes, each byte is converted to two hex digits
    return f"{secrets.token_hex(size_nbytes)}"


def hash_password(password: str) -> str:
    salt = bcrypt.gensalt()
    hashed_password = bcrypt.hashpw(password.encode('utf-8'), salt)
    return hashed_password.decode('utf-8')

def checkpw(password: str, hashed_password: str) -> bool:
    logger.debug(f"pass: {password}")
    logger.debug(f"pass2: {hashed_password}")
    logger.debug(f"result: {bcrypt.checkpw(password.encode('utf-8'), hashed_password.encode('utf-8'))}")

    return bcrypt.checkpw(password.encode('utf-8'), hashed_password.encode('utf-8'))

