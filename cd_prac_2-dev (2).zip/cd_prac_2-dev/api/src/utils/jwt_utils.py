from fastapi import Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from jose import JWTError, jwt
from config import settings
from logger import logger  # Importar el logger

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="v1/auth/token")

# Función para obtener el rol del usuario desde el token JWT
def get_current_user_role(token: str = Depends(oauth2_scheme)):
    logger.info("Validando token JWT para obtener el rol del usuario.")
    try:
        payload = jwt.decode(token, settings.SECRET_KEY, algorithms=["HS256"])
        role = payload.get("role")
        if role is None:
            logger.warning("El token JWT no contiene el campo 'role'.")
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Role not found in token",
                headers={"WWW-Authenticate": "Bearer"},
            )
        logger.info("Rol obtenido exitosamente: %s", role)
        return role
    except JWTError as e:
        logger.warning("Error al validar el token JWT: %s", str(e))
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Could not validate credentials",
            headers={"WWW-Authenticate": "Bearer"},
        )

# Función para obtener el nombre de usuario desde el token JWT
def get_current_username(token: str = Depends(oauth2_scheme)):
    logger.info("Validando token JWT para obtener el nombre de usuario.")
    try:
        payload = jwt.decode(token, settings.SECRET_KEY, algorithms=["HS256"])
        username = payload.get("sub")
        if username is None:
            logger.warning("El token JWT no contiene el campo 'sub'.")
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Username not found in token",
                headers={"WWW-Authenticate": "Bearer"},
            )
        logger.info("Nombre de usuario obtenido exitosamente: %s", username)
        return username
    except JWTError as e:
        logger.warning("Error al validar el token JWT: %s", str(e))
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Could not validate credentials",
            headers={"WWW-Authenticate": "Bearer"},
        )

# Función para verificar roles permitidos
def role_required(allowed_roles: list):
    def verify_role(user_role: str = Depends(get_current_user_role)):
        logger.info("Verificando rol del usuario: %s", user_role)
        if user_role not in allowed_roles:
            logger.warning("Acceso denegado: rol '%s' no permitido.", user_role)
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Access forbidden: insufficient permissions",
            )
    return verify_role

# Función para verificar el token y el rol (si se requiere uno específico)
def verify_token(token: str = Depends(oauth2_scheme), required_role: str = None):
    logger.info("Verificando token y rol requerido: %s", required_role)
    try:
        payload = jwt.decode(token, settings.SECRET_KEY, algorithms=["HS256"])
        token_role = payload.get("role")
        if required_role and token_role != required_role:
            logger.warning("Acceso denegado: rol '%s' no coincide con el requerido '%s'.", token_role, required_role)
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Unauthorized role"
            )
        logger.info("Token y rol verificados exitosamente: %s", token_role)
    except JWTError as e:
        logger.warning("Error al validar el token JWT: %s", str(e))
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid token"
        )
