import logging
import contextvars
import uuid
import os
from config import settings
from fastapi import Request
from datetime import datetime
import json
from logstash_async.handler import AsynchronousLogstashHandler
from logstash_async.formatter import LogstashFormatter

# Configure context variables for request and correlation IDs
request_id_var = contextvars.ContextVar("request_id", default="no-request-id")
correlation_id_var = contextvars.ContextVar("correlation_id", default="no-correlation-id")

class CustomFormatter(logging.Formatter):
    def format(self, record):
        # Initialize the extra fields list
        extra_fields = {}

        # Collect fields that start with "+"
        for attr, value in record.__dict__.items():
            if attr.startswith("+"):
                # Remove the "+" prefix and add to `extra_fields`
                extra_fields[attr[1:]] = value

        # Convert extra fields to JSON format and assign to `record.extra`
        record.extra = json.dumps(extra_fields, ensure_ascii=False) if extra_fields else ""
        
        return super().format(record)

# Define filters to manage context IDs and custom fields
class ContextIdFilter(logging.Filter):
    def filter(self, record):
        record.context_id = correlation_id_var.get() or "no-correlation-id"
        return True

class GenericFilter(logging.Filter):
    def filter(self, record):
        record.hostname = getattr(settings, 'HOSTNAME', 'unknown-host')
        record.processName = getattr(settings, 'SYSTEM_NAME', 'unknown-system')
        return True

# Configure the logger with the custom formatter and filters
logger = logging.getLogger("template_logger")
logger.setLevel(logging.INFO)

# Construct the log file path using LOG_PATH and API_NAME from settings
log_file_path = os.path.join(settings.LOG_PATH, f"{settings.API_NAME}.log")
os.makedirs(os.path.dirname(log_file_path), exist_ok=True)

# Create and configure a file handler
file_handler = logging.FileHandler(log_file_path)
file_handler.setFormatter(CustomFormatter(
    "%(asctime)s %(levelname)s %(hostname)s %(processName)s[%(process)d]: %(context_id)s %(filename)s:%(lineno)d::%(funcName)s %(message)s %(extra)s"
))

# Create and configure a stream (console) handler
stream_handler = logging.StreamHandler()
stream_handler.setFormatter(CustomFormatter(
    "%(asctime)s %(levelname)s %(hostname)s %(processName)s[%(process)d]: %(context_id)s %(filename)s:%(lineno)d::%(funcName)s %(message)s %(extra)s"
))

# Add filters to the logger (applies to all handlers automatically)
logger.addFilter(ContextIdFilter())
logger.addFilter(GenericFilter())

# Add the handlers to the logger
logger.addHandler(file_handler)
logger.addHandler(stream_handler)

# Add Logstash handler for asynchronous log shipping
logstash_handler = AsynchronousLogstashHandler(
    host='logstash',  
    port=5044,        # Puerto x donde el Logstash escucha
    database_path='logstash.db'  # Almacenamiento local temporal de los eventos
)
logstash_handler.setFormatter(LogstashFormatter())
logger.addHandler(logstash_handler)
