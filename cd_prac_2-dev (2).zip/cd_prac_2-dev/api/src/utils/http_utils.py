#!/usr/bin/env python
# -*- coding: utf-8 -*-

import requests
import logging
from requests.structures import CaseInsensitiveDict
from logger import logger

# Configurar el logger
logger = logging.getLogger("http_requests")
logger.setLevel(logging.INFO)
handler = logging.StreamHandler()
formatter = logging.Formatter("%(asctime)s - %(levelname)s - %(message)s")
handler.setFormatter(formatter)
logger.addHandler(handler)

USERAGENT = "dist_comp"
DEFAULT_HEADERS = {"Content-Type": "application/json", "User-Agent": USERAGENT}

def post(url: str, data: dict, headers: dict = None) -> requests.Response:
    """HTTP POST request to a specified URL.

    Args:
        url (str): URL to post data.
        data (dict): Data to post as JSON.
        headers (dict, optional): HTTP request headers. Defaults to None.

    Returns:
        requests.Response: Response object containing all information.
    """
    if headers is None:
        headers = DEFAULT_HEADERS

    try:
        logger.info("POST request to URL: %s with data: %s", url, data)
        response = requests.post(
            url=url,
            json=data,
            headers=headers,
            timeout=30,
            verify=False,  # nosec - CWE-295: SSL verification disabled
        )
        logger.info("POST response status: %d", response.status_code)
        return response
    except Exception as exc:
        logger.error("POST request failed. URL: %s, Error: %s", url, str(exc))
        return None

def get(url: str, query_params: dict, headers: dict = None) -> requests.Response:
    """HTTP GET request to a specified URL.

    Args:
        url (str): URL to fetch data.
        query_params (dict): Query parameters for the request.
        headers (dict, optional): HTTP request headers. Defaults to None.

    Returns:
        requests.Response: Response object containing all information.
    """
    if headers is None:
        headers = DEFAULT_HEADERS

    try:
        logger.info("GET request to URL: %s with params: %s", url, query_params)
        response = requests.get(
            url=url,
            params=query_params,
            headers=headers,
            timeout=30,
            allow_redirects=True,
            verify=False,  # nosec - CWE-295: SSL verification disabled
        )
        logger.info("GET response status: %d", response.status_code)
        return response
    except Exception as exc:
        logger.error("GET request failed. URL: %s, Error: %s", url, str(exc))
        return None

def get_url_info_sync(url: str) -> dict:
    """Fetch final redirected URL and source code following all redirections.

    Args:
        url (str): The original URL to process.

    Returns:
        dict: Contains final URL, source code, and response headers.
    """
    logger.info("Starting URL inspection for: %s", url)
    data = {"url": None, "source_code": "", "headers": {}}

    try:
        response = requests.get(
            url=url,
            headers={"User-Agent": USERAGENT},
            timeout=30,
            allow_redirects=True,
            verify=False,  # nosec - CWE-295: SSL verification disabled
        )

        if response.status_code != 200:
            logger.warning("Invalid status code %d for URL: %s", response.status_code, url)
            return data

        # Capture the final redirected URL
        if isinstance(response.url, str):
            data["url"] = response.url
            logger.info("Final redirected URL: %s", response.url)
        else:
            logger.warning("Invalid response URL for: %s", url)

        # Check for downloadable files
        if "Content-Disposition" in response.headers and "filename" in response.headers["Content-Disposition"]:
            logger.info("Detected file download in URL: %s, skipping source code.", url)
        elif isinstance(response.text, str):
            data["source_code"] = response.text
            logger.info("Captured source code for URL: %s", url)
        else:
            logger.warning("Invalid response text for URL: %s", url)

        # Validate response headers
        if isinstance(response.headers, CaseInsensitiveDict):
            data["headers"] = response.headers
            logger.info("Captured headers for URL: %s", url)
        else:
            logger.warning("Invalid headers for URL: %s", url)

    except Exception as exc:
        logger.error("Error during URL inspection for %s: %s", url, str(exc))

    return data
