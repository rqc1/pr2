# houses_sql_dao.py
from sqlalchemy.orm import Session
from models.house import House
from models.user import User
from typing import List

def create_house(db: Session, house: House):
    db.add(house)
    db.commit()
    db.refresh(house)

def get_house_by_id(db: Session, house_id: int) -> House:
    return db.query(House).filter_by(id=house_id).first()

def update_house(db: Session, house: House):
    db.commit()
    db.refresh(house)

def delete_house(db: Session, house: House):
    db.delete(house)
    db.commit()

def search_houses_by_description(db: Session, description: str, owner_id: int = None) -> List[House]:
    query = db.query(House).filter(House.description.ilike(f"%{description}%"))
    if owner_id:
        query = query.filter_by(owner_id=owner_id)
    return query.all()

def search_houses_by_address(db: Session, address: str, owner_id: int = None) -> List[House]:
    query = db.query(House).filter(House.address.ilike(f"%{address}%"))
    if owner_id:
        query = query.filter(House.owner_id == owner_id)
    return query.all()


def list_houses_for_owner(db: Session, owner_id: int = None) -> List[House]:
    query = db.query(House)
    if owner_id:
        query = query.filter_by(owner_id=owner_id)
    return query.all()

def get_user_by_id(db: Session, user_id: int) -> User:
    return db.query(User).filter_by(id=user_id).first()
