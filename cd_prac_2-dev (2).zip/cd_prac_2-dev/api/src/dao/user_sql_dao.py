from sqlalchemy.orm import Session
from models.user import User
from routes.validation import UserCreate
from utils.crypto_utils import hash_password

# Crear un nuevo usuario en la base de datos
def create_user(db: Session, user_create: UserCreate):
    # Encriptar la contraseña antes de guardarla
    hashed_password = hash_password(user_create.password)
    
    # Crear una instancia de User con la contraseña encriptada
    db_user = User(username=user_create.username, role=user_create.role, password=hashed_password)
    
    # Agregar el usuario a la sesión y hacer commit para guardarlo en la base de datos
    db.add(db_user)
    db.commit()
    
    # Refrescar la instancia para obtener los datos actualizados, como el ID generado
    db.refresh(db_user)
    
    return db_user

# Obtener un usuario por su nombre de usuario
def get_user_by_username(db: Session, username: str):
    return db.query(User).filter(User.username == username).first()

# Obtener todos los usuarios con paginación
def get_all_users(db: Session, skip: int = 0, limit: int = 100):
    return db.query(User).offset(skip).limit(limit).all()


# Actualizar un usuario
def update_user(db: Session, user_name: str, user_update: UserCreate):
    db_user = db.query(User).filter(User.username == user_name).first()
    if db_user:
        db_user.username = user_update.username
        db_user.role = user_update.role
        db_user.password = hash_password(user_update.password)  # Reencriptamos la nueva contraseña
        db.commit()
        db.refresh(db_user)
    return db_user

# Eliminar un usuario
def delete_user(db: Session, user_name: str):
    db_user = db.query(User).filter(User.username == user_name).first()
    if db_user:
        db.delete(db_user)
        db.commit()
    return db_user
