from sqlalchemy.orm import Session
from models.tokenRefresh import TokenRefresh  # Import the ORM model


def add_token(db: Session, token: str, username: str):
    db_token = TokenRefresh(token=token, username=username)
    db.add(db_token)
    db.commit()
    db.refresh(db_token)


def get_token_by_username(db: Session, username: str) -> TokenRefresh:
    token = db.query(TokenRefresh).filter(TokenRefresh.usernmame == username).first()
    return RefreshTokenDao.to_dict(token) if token else None


def get_token_list(db: Session) -> dict:
    tokens = db.query(TokenRefresh).all()  
    return {token.username: token.token for token in tokens} 


def update_token(db: Session, token: str, username: str):
    # Buscar el token en la base de datos por username
    db_token = db.query(TokenRefresh).filter(TokenRefresh.username == username).first()

    if db_token:
        db_token.token = token
        db.commit()
        db.refresh(db_token)
        return db_token 
    else:
        return None
    
def verify_token_exists(db: Session, username: str) -> bool:
    # Verificar si el usuario existe en la base de datos
    user_exists = db.query(TokenRefresh).filter(TokenRefresh.username == username).first()
    return user_exists is not None
