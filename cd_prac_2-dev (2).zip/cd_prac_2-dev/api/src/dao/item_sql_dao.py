from sqlalchemy.orm import Session
from sqlalchemy import text

class ItemSqlDAO:
    @staticmethod
    def create_item(db: Session, name: str, description: str):
        query = text("INSERT INTO items (name, description) VALUES (:name, :description)")
        db.execute(query, {"name": name, "description": description})
        db.commit()
        
        # Fetch the last inserted item
        result = db.execute(text("SELECT * FROM items ORDER BY id DESC LIMIT 1")).first()
        # Safely access result._mapping to convert to a dictionary
        return dict(result._mapping) if result else None

    @staticmethod
    def get_item(db: Session, item_id: int):
        query = text("SELECT * FROM items WHERE id = :id")
        result = db.execute(query, {"id": item_id}).first()
        return dict(result._mapping) if result else None

    @staticmethod
    def get_items(db: Session, skip: int = 0, limit: int = 10):
        query = text("SELECT * FROM items LIMIT :limit OFFSET :skip")
        results = db.execute(query, {"limit": limit, "skip": skip}).fetchall()
        # Use _mapping to access each row as a dictionary
        return [dict(row._mapping) for row in results]

    @staticmethod
    def update_item(db: Session, item_id: int, name: str, description: str):
        query = text("UPDATE items SET name = :name, description = :description WHERE id = :id")
        db.execute(query, {"name": name, "description": description, "id": item_id})
        db.commit()
        # Return the updated item
        return ItemSqlDAO.get_item(db, item_id)

    @staticmethod
    def delete_item(db: Session, item_id: int):
        # Fetch the item before deleting
        item = ItemSqlDAO.get_item(db, item_id)
        if item:
            db.execute(text("DELETE FROM items WHERE id = :id"), {"id": item_id})
            db.commit()
        return item