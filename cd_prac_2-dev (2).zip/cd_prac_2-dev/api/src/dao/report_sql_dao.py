from sqlalchemy.orm import Session
from models.report import Report

def get_report_by_house_id(db: Session, house_id: int) -> Report:
    return db.query(Report).filter_by(house_id=house_id).first()


def save_report(db: Session, report: Report):
    db.add(report)
    db.commit()
    db.refresh(report)