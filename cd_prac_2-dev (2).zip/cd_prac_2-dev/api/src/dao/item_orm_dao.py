from sqlalchemy.orm import Session
from models.item import Item  # Import the ORM model

class ItemOrmDAO:
    @staticmethod
    def create_item(db: Session, name: str, description: str):
        db_item = Item(name=name, description=description)
        db.add(db_item)
        db.commit()
        db.refresh(db_item)
        return ItemOrmDAO.to_dict(db_item)

    @staticmethod
    def get_item(db: Session, item_id: int):
        item = db.query(Item).filter(Item.id == item_id).first()
        return ItemOrmDAO.to_dict(item) if item else None

    @staticmethod
    def get_items(db: Session, skip: int = 0, limit: int = 10):
        items = db.query(Item).offset(skip).limit(limit).all()
        return [ItemOrmDAO.to_dict(item) for item in items]

    @staticmethod
    def update_item(db: Session, item_id: int, name: str, description: str):
        db_item = db.query(Item).filter(Item.id == item_id).first()
        if db_item:
            db_item.name = name
            db_item.description = description
            db.commit()
            db.refresh(db_item)
        return ItemOrmDAO.to_dict(db_item) if db_item else None

    @staticmethod
    def delete_item(db: Session, item_id: int):
        db_item = db.query(Item).filter(Item.id == item_id).first()
        if db_item:
            db.delete(db_item)
            db.commit()
        return ItemOrmDAO.to_dict(db_item) if db_item else None

    @staticmethod
    def to_dict(item):
        # Convert the ORM item object to a dictionary
        return {"id": item.id, "name": item.name, "description": item.description}
