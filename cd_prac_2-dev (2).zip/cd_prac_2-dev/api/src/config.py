import os
import socket
from pydantic_settings import BaseSettings

class Settings(BaseSettings):
    
    API_NAME: str = os.getenv("API_NAME", "PROJECT02_API"),
   
    SECRET_KEY: str = os.getenv("SECRET_KEY", "your_mocked_secret_key"),
    ACCESS_TOKEN_EXPIRE_MINUTES: str = os.getenv("ACCESS_TOKEN_EXPIRE_MINUTES", "10")
    REFRESH_TOKEN_EXPIRE_MINUTES: str = os.getenv("REFRESH_TOKEN_EXPIRE_MINUTES", "360")

    DATABASE_URL: str = os.getenv("DATABASE_URL", "sqlite:///./mock.db")
    HOSTNAME: str = os.getenv("HOSTNAME", socket.gethostname())
    SYSTEM_NAME: str = os.getenv("SYSTEM_NAME", "N/A")
    SQLALCHEMY_TRACK_MODIFICATIONS: bool = False

    # MySQL-specific environment variables
    MYSQL_HOST: str = os.getenv("MYSQL_HOST", "localhost")
    MYSQL_PORT: str = os.getenv("MYSQL_PORT", "3306")
    MYSQL_USER: str = os.getenv("MYSQL_USER", "myuser")
    MYSQL_PASSWORD: str = os.getenv("MYSQL_PASSWORD", "mypassword")
    MYSQL_DATABASE: str = os.getenv("MYSQL_DATABASE", "project02")

    # Construct the full DATABASE_URL dynamically
    DATABASE_URL: str = f"mysql+pymysql://{MYSQL_USER}:{MYSQL_PASSWORD}@{MYSQL_HOST}:{MYSQL_PORT}/{MYSQL_DATABASE}"

    LOG_PATH: str = os.getenv("LOG_PATH", "storefiles/logs/"),
    

settings = Settings()