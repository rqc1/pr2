import uvicorn
import time
import uuid
from contextlib import asynccontextmanager
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from config import settings
from models.user import Base
from database import engine
from database import SessionLocal  # Assuming you have a SessionLocal in database.py
from routes.v1 import auth, users, houses, report
from routes.examples import logging, db_orm, db_sql, role_based_access
from utils.logger import logger, request_id_var, correlation_id_var

#logging config
@router.get("/users/{user_id}", status_code=200)
async def get_user(user_id: int):
    try:
        logger.info(f"Solicitud para recuperar usuario: {user_id}")
        user = {"id": user_id, "username": "test_user"}
        return user
    except Exception as e:
        logger.error(f"Error al recuperar usuario {user_id}: {str(e)}")
        raise HTTPException(status_code=500, detail="Internal server error")

#TODO: Implement Logging in the entire proyect us

# Initialize FastAPI app
app = FastAPI()

#disable automatic documentation
#app = FastAPI(docs_url=None, redoc_url=None, openapi_url=None) 

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup logic
    logger.info("{settings.SYSTEM_NAME} starting up...")

    yield  # Runs during the application lifecycle

    # Shutdown logic
    logger.info("{settings.SYSTEM_NAME} shutting down...")

# allow CORS middleware
app.add_middleware(
    CORSMiddleware,
    # NOTE: we can configure allowed hosts here
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

#add middleware to log all requests
@app.middleware("http")
async def log_requests(request: Request, call_next):
    try: 
        start_time = time.time()

         # Generate a request ID and set it in the context
        request_id = request.headers.get("X-Request-ID", str(uuid.uuid4()))
        request_id_var.set(request_id)

        # Check for an existing correlation ID in headers; otherwise, create one
        correlation_id = request.headers.get("X-Correlation-ID", str(uuid.uuid4()))
        correlation_id_var.set(correlation_id)

        # Create a new database session
        request.state.db = SessionLocal()
        
        logger.info(f"rid={request_id} cid={correlation_id} start request path={request.url.path}")
        
        response = await call_next(request)

        # Add the request ID and correlation ID to the response headers
        response.headers["X-Request-ID"] = request_id
        response.headers["X-Correlation-ID"] = correlation_id
        
        process_time = (time.time() - start_time) * 1000
        formatted_process_time = '{0:.2f}'.format(process_time)

        # logger.info(f"rid={idem} completed_in={formatted_process_time}ms status_code={response.status_code}")
        logger.info(f"completed_in={formatted_process_time}ms status_code={response.status_code}")

        # Clear context variables after the request
        request_id_var.set(None)
        correlation_id_var.set(None)

        return response
    
    except Exception as e:
        # Calculate processing time and log error without referencing `response`
        process_time = (time.time() - start_time) * 1000
        formatted_process_time = '{0:.2f}'.format(process_time)
        logger.error(f"Error processing request: {str(e)} completed_in={formatted_process_time}ms")
        raise e

# Create database tables
Base.metadata.create_all(bind=engine)

# Include routes for v1 API
app.include_router(auth.router, tags=["default"], prefix="/v1/auth")
app.include_router(users.router, tags=["default"], prefix="/v1/users")
app.include_router(houses.router, tags=["default"], prefix="/v1/users/{user_id}/homes")
app.include_router(report.router, tags=["default"], prefix="/v1/users/{user_id}/homes/{report_id}")

#Include examples
app.include_router(db_orm.router, tags=["db_orm"], prefix="/examples/db")
app.include_router(db_sql.router, tags=["db_sql"], prefix="/examples/db")
app.include_router(logging.router, tags=["logging"], prefix="/examples/logging")
app.include_router(role_based_access.router, tags=["rbac"], prefix="/examples/rbac")

if __name__ == "__main__":
    uvicorn.run("main:app", host="0.0.0.0", port=8090, reload=True)