from config import settings
from fastapi import Depends, Request, HTTPException
from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker,Session

engine = create_engine(
    settings.DATABASE_URL,
    pool_recycle=1800,         # Recycle connections every 1800 seconds (30 minutes)
    pool_pre_ping=True,        # Check connections before use
)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()

def get_db(request: Request):
    db: Session = request.state.db
    if db is None:
        raise HTTPException(status_code=500, detail="Database session is not available")
    return db