# City Council Service

This service provides functionality to register and verify home ownership through both WebSocket and SOAP interfaces. The system uses a MySQL database to store home information and verifies ownership by matching the name and address.

## Services

### 1. WebSocket Service (Port: 8082)
Allows batch registration of multiple homes and real-time verification.

#### WebSocket Endpoints
- **add_home**: Adds a new home. 
  - Request: `{ "action": "add_home", "owner_name": "John Doe", "address": "123 Main St" }`
- **verify_home**: Verifies if a home exists by owner name and address.
  - Request: `{ "action": "verify_home", "owner_name": "John Doe", "address": "123 Main St" }`
  - Response: `{ "verified": true }`
- **ping**: Checks connection.
  - Request: `{ "action": "ping" }`
  - Response: `pong`

### 2. SOAP Service (Port: 8083)
Provides individual home registration and verification with the city council’s database.

#### SOAP Endpoints
- **/soap/add_home** (POST): Registers a new home.
  - Request: `owner_name` (string), `address` (string)
- **/soap/verify_home** (GET): Verifies home ownership.
  - Request: `owner_name` (string), `address` (string)
  - Response: `{ "verified": true }`
- **/soap/list_homes** (GET): Lists all registered homes.
  - Response: `{ "homes": [...] }`

  See the postman available in the folder postman

## Database Setup
The service connects to a MySQL database with the following credentials:
- User: `user1024`
- Password: `DKDbRQ8EzY4Q`
- Database: `city_council_db`

## Running the Service
1. Build and run the Docker Compose setup:
   ```bash
   docker-compose up --build


## WebSocket Connection

- **URL**: `ws://localhost:8092`
- This WebSocket service uses Basic Authentication through an initial authentication message.

Make sure to authenticate before performing any other action. The service also provides a `ping` action to check the connection's health.

## WebSocket Structure and Actions

### Authentication

The client must first authenticate to interact with the WebSocket service. Authentication is achieved by sending a JSON message with the username and password fields as part of the first message. Once authenticated, the client can proceed with other actions like adding a home, verifying home ownership, or sending a ping.

#### Authentication Message Structure

```json
{
  "action": "authenticate",
  "username": "your_username",
  "password": "your_password"
}
```

- **Username** and **Password**: These credentials are verified by the WebSocket server. If correct, access is granted; otherwise, the connection is closed.

### Actions

1. **add_home**
   - Registers a new home with the provided owner name and address.
   - **Message Structure**:
     ```json
     {
       "action": "add_home",
       "owner_name": "Owner Name",
       "address": "Home Address"
     }
     ```
   - **Response**: Returns "OK" if the home was successfully added.

2. **verify_home**
   - Verifies if a specific home is registered in the system based on the owner's name and address.
   - **Message Structure**:
     ```json
     {
       "action": "verify_home",
       "owner_name": "Owner Name",
       "address": "Home Address"
     }
     ```
   - **Response**: Returns `{"verified": true}` if the home is found or `{"verified": false}` if it is not.

3. **ping**
   - A simple health check to confirm the connection is active.
   - **Message Structure**:
     ```json
     {
       "action": "ping"
     }
     ```
   - **Response**: Returns "pong".

## Usage Examples

### Connecting to the WebSocket Service

Below are examples of how to connect and interact with the WebSocket service in various programming languages.

### Node.js Example

```javascript
const WebSocket = require('ws');

const ws = new WebSocket('ws://localhost:8092');

ws.on('open', function open() {
  // Authenticate
  ws.send(JSON.stringify({
    action: 'authenticate',
    username: 'your_username',
    password: 'your_password'
  }));

  // Add home
  ws.send(JSON.stringify({
    action: 'add_home',
    owner_name: 'John Doe',
    address: '123 Main St'
  }));

  // Verify home
  ws.send(JSON.stringify({
    action: 'verify_home',
    owner_name: 'John Doe',
    address: '123 Main St'
  }));

  // Send ping
  ws.send(JSON.stringify({
    action: 'ping'
  }));
});

ws.on('message', function incoming(data) {
  console.log('Received:', data);
});
```

### Pure JavaScript (Browser) Example

```html
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>WebSocket Example</title>
</head>
<body>
  <script>
    const ws = new WebSocket('ws://localhost:8092');

    ws.onopen = function () {
      // Authenticate
      ws.send(JSON.stringify({
        action: 'authenticate',
        username: 'your_username',
        password: 'your_password'
      }));

      // Add home
      ws.send(JSON.stringify({
        action: 'add_home',
        owner_name: 'Jane Doe',
        address: '456 Elm St'
      }));

      // Verify home
      ws.send(JSON.stringify({
        action: 'verify_home',
        owner_name: 'Jane Doe',
        address: '456 Elm St'
      }));

      // Send ping
      ws.send(JSON.stringify({
        action: 'ping'
      }));
    };

    ws.onmessage = function (event) {
      console.log('Received:', event.data);
    };

    ws.onclose = function () {
      console.log('Connection closed');
    };
  </script>
</body>
</html>
```

### Java Example

```java
import java.net.URI;
import java.nio.ByteBuffer;
import javax.websocket.*;

@ClientEndpoint
public class WebSocketClient {

    private static final String SERVER_URI = "ws://localhost:8092";
    private Session session;

    public WebSocketClient() {
        try {
            WebSocketContainer container = ContainerProvider.getWebSocketContainer();
            container.connectToServer(this, new URI(SERVER_URI));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @OnOpen
    public void onOpen(Session session) {
        this.session = session;
        System.out.println("Connected to server");

        // Authenticate
        sendMessage("{\"action\": \"authenticate\", \"username\": \"your_username\", \"password\": \"your_password\"}");

        // Add home
        sendMessage("{\"action\": \"add_home\", \"owner_name\": \"Alice Doe\", \"address\": \"789 Oak St\"}");

        // Verify home
        sendMessage("{\"action\": \"verify_home\", \"owner_name\": \"Alice Doe\", \"address\": \"789 Oak St\"}");

        // Send ping
        sendMessage("{\"action\": \"ping\"}");
    }

    @OnMessage
    public void onMessage(String message) {
        System.out.println("Received: " + message);
    }

    @OnClose
    public void onClose(Session session, CloseReason closeReason) {
        System.out.println("Connection closed: " + closeReason);
    }

    private void sendMessage(String message) {
        session.getAsyncRemote().sendText(message);
    }

    public static void main(String[] args) {
        new WebSocketClient();
    }
}
```