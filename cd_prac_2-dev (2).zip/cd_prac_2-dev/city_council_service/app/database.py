import mysql.connector
import os
from mysql.connector import Error
import logging
logging.basicConfig(level=logging.DEBUG)

def get_db_connection():
    """
    Establish a connection to the city_council_db database.
    """
    try:
        connection = mysql.connector.connect(
            host=os.getenv("MYSQL_HOST", "mysql"),
            port=os.getenv("MYSQL_PORT", "3306"),
            user=os.getenv("MYSQL_USER", "council_user"),
            password=os.getenv("MYSQL_PASSWORD", "councilpass"),
            database=os.getenv("MYSQL_DATABASE", "city_council_db")
        )
        if connection.is_connected():
            logging.info("Connected to city_council_db database")
        return connection
    except Error as e:
        logging.error(f"Error connecting to city_council_db database: {e}")
        return None