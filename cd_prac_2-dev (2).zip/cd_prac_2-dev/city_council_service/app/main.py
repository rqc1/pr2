import asyncio
from websockets.asyncio.server import serve

import logging
from websocket_service import websocket_handler
from soap_service import wsgi_app
from wsgiref.simple_server import make_server

logging.basicConfig(level=logging.DEBUG)
logging.getLogger('spyne.protocol.xml').setLevel(logging.DEBUG)

async def start_websocket_server():
    async with serve(websocket_handler, "0.0.0.0", 8092):
        await asyncio.Future()  # Run forever

async def start_wsgi_server():
    """Run the WSGI server in an executor."""
    logging.info("City Council SOAP service is running on http://0.0.0.0:8093")
    logging.info("WSDL is available at: http://0.0.0.0:8093/?wsdl")
    server = make_server("0.0.0.0", 8093, wsgi_app)
    loop = asyncio.get_running_loop()
    await loop.run_in_executor(None, server.serve_forever)

async def main():
    """Run both the WebSocket and WSGI servers concurrently."""
    await asyncio.gather(
        start_websocket_server(),
        start_wsgi_server(),
    )

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        logging.info("Shutting down services.")

# if __name__ == "__main__":

#     # loop = asyncio.get_event_loop()
#     # loop.create_task(start_websocket_server())
    
#     server = make_server("0.0.0.0", 8093, wsgi_app)
#     logging.info("City Council SOAP service is running on http://0.0.0.0:8093")
#     logging.info("wsdl is at: http://0.0.0.0:8093/?wsdl")
#     server.serve_forever()

#     asyncio.run(start_websocket_server())
#     logging.info("City Council Websocket service is running on http://0.0.0.0:8092")