from spyne import Application, ServiceBase, Unicode, Integer, Boolean
from spyne.decorator import srpc
from spyne.protocol.soap import Soap11
from spyne.server.wsgi import WsgiApplication
from spyne.model.complex import Iterable
from spyne.model.primitive import String, Boolean, UnsignedInteger
from database import get_db_connection

class CityCouncilService(ServiceBase):
    
    @srpc(String, String, _returns=String)
    def add_home(owner_name, address) -> Unicode:
        """
        Verifies if a home exists by owner name and address.
        If the home does not exist, it adds it to the database.
        """
        # Verificar si la casa ya está registrada
        if not CityCouncilService.verify_home(owner_name, address):
            db = get_db_connection()
            cursor = db.cursor()
            cursor.execute("INSERT INTO homes (owner_name, address) VALUES (%s, %s)", (owner_name, address))
            db.commit()
            db.close()
            return "Home added successfully"
        else:
            return "Home is already registered"
        
    @srpc(String, String, _returns=Boolean)
    def verify_home(owner_name, address):
        """
        Verifies if a home exists by owner name and address.
        """
        db = get_db_connection()
        cursor = db.cursor(dictionary=True)
        cursor.execute("SELECT * FROM homes WHERE owner_name=%s AND address=%s", (owner_name, address))
        result = cursor.fetchone()
        db.close()
        return bool(result)

    @srpc(_returns=Iterable(String))
    def list_homes():
        """
        Lists all homes.
        """
        db = get_db_connection()
        cursor = db.cursor(dictionary=True)
        cursor.execute("SELECT * FROM homes")
        homes = cursor.fetchall()
        db.close()
        homes_list = [f"{home['owner_name']} at {home['address']}" for home in homes]
        return homes_list

# Set up the Spyne application
application = Application(
    [CityCouncilService],
    "city.council.soap.service",
    in_protocol=Soap11(validator="lxml"),
    out_protocol=Soap11()
)

# Create a WSGI application
wsgi_app = WsgiApplication(application)

#TODO: ADD basic authentication
