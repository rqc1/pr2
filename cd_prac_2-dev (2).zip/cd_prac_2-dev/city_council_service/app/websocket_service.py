import json,os
import base64, websockets
from database import get_db_connection
import asyncio
import logging

logging.basicConfig(level=logging.DEBUG)
# logging.getLogger('spyne.protocol.xml').setLevel(logging.DEBUG)

# Define las credenciales válidas
VALID_USERNAME = os.getenv("SOCKET_USER", None)
VALID_PASSWORD = os.getenv("SOCKET_PASS", None)

async def websocket_handler(websocket):
    try:
        # Espera el primer mensaje para la autenticación
        message = await websocket.recv()
        data = json.loads(message)

        # Verifica que el mensaje contenga la acción de autenticación y las credenciales
        if data.get("action") != "authenticate" or "username" not in data or "password" not in data:
            await websocket.send("Authentication required")
            await websocket.close()
            return

        # Decodifica y valida las credenciales
        username = data["username"]
        password = data["password"]

        if username != VALID_USERNAME or password != VALID_PASSWORD:
            await websocket.send("Invalid credentials")
            await websocket.close()
            return

        # Autenticación exitosa: continuar con los otros mensajes
        await websocket.send("Authentication successful")

        async for message in websocket:
            data = json.loads(message)
            action = data.get("action")
            if action == "add_home":
                await add_home(data)
                await websocket.send("OK")
            elif action == "verify_home":
                result = await verify_home(data["owner_name"], data["address"])
                await websocket.send(json.dumps(result))
            elif action == "ping":
                await websocket.send("pong")
            else:
                await websocket.send("Unknown action")
    
    except websockets.exceptions.ConnectionClosedOK:
            logging.info("Client disconnected gracefully.")
    except json.decoder.JSONDecodeError:
            await websocket.send("The message cant be decoded as JSON")
    except Exception as e:
            logging.error(f"Error processing message: {e}")
            if websocket.open:
                await websocket.send("Error processing message")

async def add_home(data):
    db = get_db_connection()
    cursor = db.cursor()
    cursor.execute("INSERT INTO homes (owner_name, address) VALUES (%s, %s)", (data["owner_name"], data["address"]))
    db.commit()
    db.close()

async def verify_home(owner_name, address):
    db = get_db_connection()
    cursor = db.cursor(dictionary=True)
    cursor.execute("SELECT * FROM homes WHERE owner_name=%s AND address=%s", (owner_name, address))
    result = cursor.fetchone()
    db.close()
    return {"verified": bool(result)}
