class Home:
    def __init__(self, id, owner_name, address):
        self.id = id
        self.owner_name = owner_name
        self.address = address