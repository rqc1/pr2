import base64
import uvicorn
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from enum import Enum
from typing import Optional
import requests_async as requests
import random
import string
import json

app = FastAPI()

# Enum for report status mapping
class ReportStatus(int, Enum):
    generating = 1
    done = 2
    error = 3
    retry = 4

# Webhook request data model
# Webhook request data model
class WebhookRequest(BaseModel):
    id: int = Field(..., example=123)
    home_id: int = Field(..., example=456)
    owner_name: str = Field(..., example="John Doe")
    report_status: ReportStatus = Field(..., description="Status of the report generation: 1-generating, 2-done, 3-error, 4-retry")
    token: Optional[str] = Field(None)

# Webhook endpoint to receive status updates
@app.post("/webhook")
async def webhook(data: WebhookRequest):
    # Map status to descriptive text
    status_text = {
        ReportStatus.generating: "Generating",
        ReportStatus.done: "Done",
        ReportStatus.error: "Error",
        ReportStatus.retry: "Retry"
    }

    # Log the received data for demonstration
    report_status_text = status_text[data.report_status]
    print(f"Received webhook for ID: {data.id}, HomeID: {data.home_id}, Owner: {data.owner_name}, Status: {report_status_text}")

    # Placeholder for further processing if needed
    # You could save this data to a database, trigger other processes, etc.

    random_code = ''.join(random.choices(string.ascii_lowercase + string.digits, k=6))
    
    # Crear la ruta del archivo con el código aleatorio
    output_pdf_path = f"storefiles/reports/{random_code}_{data.owner_name}_report.pdf"

    if "Done" in report_status_text:
        response = await get_report(user_id=data.id, home_id=data.home_id, house_id=data.home_id, token=data.token)
        report = response.get("pdf_report")
        if report == None:
            raise HTTPException(
                status_code=404,
                detail="no es troba el fitxer pdf a la resposta enviada"
            )
        generate_pdf_from_base64(base64_data=report, output_pdf_path=output_pdf_path)


    return {"status": "success", "message": f"Received report status update: {report_status_text}"}


async def get_report(user_id, home_id, house_id, token):
    # Formatear la URL con los valores de user_id y home_id
    url = f"http://api_service:8090/v1/users/{user_id}/homes/{home_id}/report?house_id={house_id}"
    
    # Definir los encabezados, incluyendo el token de autorización
    headers = {
        'Authorization': f'Bearer {token}'
    }
    
    # Realizar la solicitud GET
    response = await requests.get(url, headers=headers)
    
    # Comprobar si la respuesta fue exitosa
    if response.status_code == 200:
        try:
            # Intentar convertir la respuesta en formato JSON
            response_json = response.json()
            print(f"Reporte recibido correctamente")
            return response_json  # Devolver la respuesta en formato JSON
        except json.JSONDecodeError:
            # Si no se puede convertir la respuesta en JSON, lanzar una excepción
            raise HTTPException(
                status_code=500,
                detail="Error al decodificar la respuesta JSON."
            )
    else:
        # Si la solicitud no fue exitosa, lanzar una excepción con el error
        raise HTTPException(
            status_code=response.status_code,
            detail=f"Error al obtener el reporte: {response.text}"
        )


def generate_pdf_from_base64(base64_data: str, output_pdf_path: str):
    # Decodificar la cadena base64
    pdf_data = base64.b64decode(base64_data)

    # Escribir los bytes en un archivo PDF
    with open(output_pdf_path, 'wb') as pdf_file:
        pdf_file.write(pdf_data)
    print(f"PDF generado en {output_pdf_path}")

if __name__ == "__main__":
    uvicorn.run("main:app", host="0.0.0.0", port=8089, reload=True)